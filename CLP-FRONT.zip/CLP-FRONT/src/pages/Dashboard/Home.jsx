

import DashboardTable from "../../components/dashboard/DashboardTable";




export default function Home() {
  return (
    <>
      <DashboardTable/>
    </>
  );
}
