import React from 'react'

const StudyMaterialList = () => {
  return (
    <div>
      <StudyMaterialList/>
    </div>
  )
}

export default StudyMaterialList
