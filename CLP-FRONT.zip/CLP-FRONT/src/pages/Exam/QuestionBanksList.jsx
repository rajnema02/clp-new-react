import React from 'react'
import QuestionBankList from '../../components/Exam/QuestionBankList'

const QuestionBanksList = () => {
  return (
    <div>
      <QuestionBankList/>
    </div>
  )
}

export default QuestionBanksList
