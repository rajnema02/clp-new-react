import React from 'react'
import StudyMaterialList from '../../components/studyMaterialDetails/StudyMaterialList'

const ScheduleExamsList = () => {
  return (
    <div>
      <StudyMaterialList/>
    </div>
  )
}

export default ScheduleExamsList