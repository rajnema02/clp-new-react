import React from 'react'

const BulkUploadsList = () => {
  return (
    <div>
      <BulkUploadsList/>
    </div>
  )
}

export default BulkUploadsList
