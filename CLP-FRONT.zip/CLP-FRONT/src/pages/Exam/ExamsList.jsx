import React from 'react'

const ExamsList = () => {
  return (
    <div>
      <ExamsList/>
    </div>
  )
}

export default ExamsList
