import React from 'react'
import BatchDetails from '../../components/batchDetails/BatchDetails'



export default function BatchData() {
  return (
    <>
      <BatchDetails/>
    </>
  );
}