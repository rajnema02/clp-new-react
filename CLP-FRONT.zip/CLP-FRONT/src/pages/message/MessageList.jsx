import React from 'react'
import Messages from '../../components/messages/Messages'

const MessageList = () => {
  return (
    <div>
      <Messages/>
    </div>
  )
}

export default MessageList
