import React from 'react'
import CourseList from '../../components/Course/CourseList'

const CourseLists = () => {
  return (
    <div>
      <CourseList/>
    </div>
  )
}

export default CourseLists
