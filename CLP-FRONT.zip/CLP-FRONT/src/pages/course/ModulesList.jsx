import React from 'react'
import Module from '../../components/Course/ModuleList'
import ModuleList from '../../components/Course/ModuleList'

const ModulesList = () => {
  return (
    <div>
      <ModuleList/>
    </div>
  )
}

export default ModulesList
