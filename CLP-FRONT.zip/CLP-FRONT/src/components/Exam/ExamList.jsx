import React from 'react'

const ExamList = () => {
  return (
    <div>
      
    </div>
  )
}

export default ExamList
