import React from 'react'

const BulkUploadList = () => {
  return (
    <div>
      
    </div>
  )
}

export default BulkUploadList
