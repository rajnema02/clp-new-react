import React from 'react'

const QuestionBankList = () => {
  return (
    <div>
      
    </div>
  )
}

export default QuestionBankList
